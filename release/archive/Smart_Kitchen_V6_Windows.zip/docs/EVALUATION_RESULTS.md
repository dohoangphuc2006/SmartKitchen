# Kết quả kiểm thử kỹ thuật

Kiểm thử trên Windows 11 build 26200, CPython 3.14.3 x64 và Chrome headless. Bản thử được giải nén vào thư mục mới có dấu tiếng Việt và khoảng trắng. Script tạo `.venv` mới, tải wheel từ PyPI, chạy `pip check` và preflight. Nguồn V6 và môi trường phát triển không tham gia chạy sản phẩm.

| Kiểm thử | Kết quả quan sát |
| --- | --- |
| Giải nén, kiểm tra SHA-256, cài thư viện, `pip check` và preflight | PASS |
| Khởi động bằng `Start_Smart_Kitchen.cmd`. Trang chủ và endpoint danh mục | PASS, HTTP 200. `final` là mặc định |
| Pantry `thịt heo xay`, `trứng`, `trứng, cà chua, hành lá` × Stage 5/TF-IDF/LSA | PASS, 9/9 tổ hợp |
| Stage 5 một danh sách, ngoài luồng hai tầng | PASS, trả 5 công thức với trứng/cà chua/hành lá |
| Hai tầng | PASS. Với riêng thịt heo xay, Tầng A trống và Tầng B có 5 món. Với pantry trứng/cà chua/hành lá, mỗi phương pháp trả 2 món Tầng A và 5 món Tầng B |
| Hash và version ML qua API | PASS, `recipe_tfidf_lsa_v1` và SHA-256 khớp metadata cho cả TF-IDF và LSA |
| Chi tiết qua API, #417, #999, #6236 | PASS, nguyên bản tiếng Anh và trường VI `auto_unreviewed` còn nguyên nhãn |
| Chi tiết #103, dịch nguyên liệu theo yêu cầu | PASS, ghi cache riêng. Bước nấu vẫn dùng EN gốc và có trạng thái `untranslated` |
| Trình duyệt thật | PASS, thêm/xóa pantry, tạo gợi ý, xem cả hai tầng, mở công thức, đổi VI → EN → VI cho tiêu đề, nguyên liệu, bước nấu và nhãn hộp thoại |
| Pantry `phieu12` | PASS, API trả danh sách trống với lý do `NO_RECOGNIZED_INGREDIENTS`; giao diện hiển thị trạng thái trống |
| Xung đột cổng | PASS, preflight báo rõ cổng 8000 bận, trả mã 3 và tiến trình đang phục vụ vẫn trả HTTP 200 |
| Khởi động tiến trình mới trên 8066 | PASS, ID và thứ tự từng tầng trùng ở 9/9 tổ hợp. Hash các tệp được kiểm tra lại sau khi tạo cache |
| 13 nhóm test JavaScript V6 dùng được trong gói | PASS trên Node.js 24.16.0. Node.js chỉ dùng cho kiểm thử bổ sung |
| Nhận diện YOLO trên ảnh thật | Không thuộc phạm vi kiểm thử profile `recipe` của ZIP Windows |

Catalog đã xử lý có 13.501 dòng công thức và 145.024 dòng chi tiết nguyên liệu. Đầu vào fit của model có 13.489 công thức. Danh mục pantry có 526 mục trong 12 nhóm.

Số liệu trên đo kiểm hành vi hệ thống. Human evaluation ở trạng thái `QUALITY_FLAGGED` và chưa đạt nghiệm thu. Independent holdout ở mức 0/30, chưa đạt nghiệm thu. Trạng thái chọn mô hình là `MODEL_SELECTION_NOT_ESTABLISHED`. Xem [giới hạn học thuật](ACADEMIC_LIMITATIONS.md), [báo cáo bàn giao V6](E2E_VERIFICATION_REPORT.md) và [bảng đối chiếu kỹ thuật V6](VERIFIED_COMPARISON_TABLE.md) để truy vết số liệu lịch sử.
