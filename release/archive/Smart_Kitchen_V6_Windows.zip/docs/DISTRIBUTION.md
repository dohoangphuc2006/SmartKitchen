# Quyền phân phối và phát hành GitHub

**Trạng thái quyền chia sẻ: chờ xác nhận.** Gói giữ bản sao cục bộ để kiểm định. Owner cần xác nhận phạm vi chia sẻ trước khi đưa bất kỳ tài sản đang chờ xác minh nào lên GitHub hoặc gửi cho giảng viên.

| Tài sản | Bằng chứng hiện có / việc cần xác nhận | Tác động nếu loại bỏ |
| --- | --- | --- |
| Catalog và lineage ở `app/processed/`, gồm nội dung tiếng Anh của công thức | Nguồn V6 ghi CC BY-SA 3.0 theo nhà đăng/mirror. Giữ attribution, revision, mô tả thay đổi và điều khoản ShareAlike. V6 chỉ có ghi nhận ở cấp dataset, chưa có hồ sơ quyền từ Epicurious hoặc tác giả cho từng bài. Owner cần xác nhận phạm vi áp dụng cho nội dung thực sự phân phối. | Thiếu catalog và lineage ứng dụng không khởi động đúng. Không xem được chi tiết gốc. |
| Danh mục pantry, ánh xạ và nội dung VI ở `app/config/`, `app/mapping/`, `app/processed/` và `app/translations/` | Có dữ liệu dẫn xuất và phần do nhóm biên soạn. Xác nhận quyền của các bên đóng góp và điều khoản áp dụng cho phần dẫn xuất. Bản dịch tự động giữ nhãn `auto_unreviewed`. | Thiếu catalog hoặc mapping làm hỏng nhập liệu/xếp hạng. Thiếu batch dịch làm giảm độ phủ tiếng Việt. |
| `app/models/recipe_ml/recipe_tfidf_lsa_v1.npz` và metadata | Artifact fit cục bộ từ catalog, có SHA-256 và lineage. V6 chưa kèm quyết định cấp quyền riêng cho artifact và metadata. | TF-IDF và LSA không chạy. Bản ZIP đầy đủ yêu cầu cả hai tệp. |
| `app/models/best.pt` | Checkpoint YOLO gốc có hash từ V6. V6 chưa kèm bằng chứng quyền phân phối của checkpoint và dữ liệu liên quan. Giữ cục bộ, profile mặc định tắt nhận diện. | Profile nhập nguyên liệu thủ công có thể chạy nếu đóng gói và kiểm thử lại một ZIP bỏ YOLO. Tính năng ảnh/camera cần trọng số và môi trường YOLO. |
| Mã nguồn, giao diện và tài liệu nhóm | V6 chưa có giấy phép mã dự án. Owner cần có quyền từ các tác giả và quyết định điều khoản áp dụng. | Không thể phân phối mã ứng dụng hoặc tài liệu chịu quyền khi chưa có xác nhận. |

Nguồn tham chiếu gồm [metadata ghi trong V6](../app/data/recipes_raw/SOURCE.json), [mirror và giấy phép tự khai báo](https://huggingface.co/datasets/Hieu-Pham/kaggle_food_recipes), [CC BY-SA 3.0](https://creativecommons.org/licenses/by-sa/3.0/). V6 chỉ kèm dữ liệu văn bản đã xử lý, không có ảnh công thức và không cần tải dataset gốc.

## Giới hạn dung lượng

| Tệp | Byte | MiB |
| --- | ---: | ---: |
| `app/models/recipe_ml/recipe_tfidf_lsa_v1.npz` | 92.791.550 | 88,49 |
| `app/processed/recipes_cleaned.csv` | 50.879.189 | 48,52 |
| `app/processed/ingredient_details.csv` | 31.921.373 | 30,44 |

Cả ba vượt giới hạn 25 MiB của giao diện thêm file vào repository. Artifact NPZ cũng vượt mức cảnh báo 50 MiB. Các file bên trong ZIP đều dưới ngưỡng chặn Git 100 MiB. ZIP hoàn chỉnh phù hợp giới hạn dưới 2 GiB cho một Release asset. [Giới hạn GitHub](https://docs.github.com/en/repositories/working-with-files/managing-large-files/about-large-files-on-github) · [GitHub Releases](https://docs.github.com/en/repositories/releasing-projects-on-github/about-releases)

## Owner phát hành sau khi quyền chia sẻ được xác nhận

1. Tạo/chọn repository đúng phạm vi đã được duyệt. Nếu giảng viên là đối tượng duy nhất, thiết lập quyền truy cập tương ứng và xác minh giảng viên tải được asset bằng tài khoản của họ.
2. Đưa nội dung mã, tài liệu, manifest và tài sản đã được duyệt lên repository bằng Git CLI. Loại ZIP khỏi lịch sử Git theo `.gitignore`. Nếu thay đổi điều khoản, mã hoặc dữ liệu trong ZIP, tạo lại manifest và kiểm thử bản giải nén mới.
3. Tạo GitHub Release với tag `2026-11-17-v6-submission`. Đính kèm `release/Smart_Kitchen_V6_Windows.zip` và `release/Smart_Kitchen_V6_Windows.zip.sha256` trong **Assets**. Bản ZIP chứa các byte thật của model và dữ liệu.
4. Gửi giảng viên link trực tiếp tới Release và chỉ rõ tên asset. GitHub sinh thêm `Source code (zip)` tự động. Bản phân phối Windows cần dùng là ZIP đính kèm có SHA-256 bên cạnh.
