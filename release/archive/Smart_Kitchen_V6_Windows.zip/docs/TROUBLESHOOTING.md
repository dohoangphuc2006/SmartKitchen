# Xử lý lỗi trên Windows

| Hiện tượng | Cách xử lý |
| --- | --- |
| Cần CPython 3.14 64-bit | Cài bản x64 trong README. Mở lại PowerShell sau khi cài. Với môi trường `.venv` tạo bằng phiên bản khác, đổi tên môi trường cũ rồi cài lại. |
| Cài thư viện thất bại | Kiểm tra kết nối đến `pypi.org` và `files.pythonhosted.org` rồi chạy lại setup. Các wheel được cài vào `.venv` tại chỗ. |
| Thiếu tệp hoặc sai SHA-256 | Tải lại ZIP đính kèm trong **Assets** rồi giải nén vào thư mục mới. Kiểm tra SHA-256 ZIP theo hướng dẫn bên dưới. |
| Cổng 8000 bận | Dùng lệnh đổi cổng bên dưới, hoặc dừng phiên Smart Kitchen do bạn mở bằng Ctrl+C. |
| Trình duyệt không kết nối | Đợi `Application startup complete` và mở URL in trong cửa sổ server. |
| Gợi ý trống | Kiểm tra nguyên liệu đã được xác nhận và thêm nguyên liệu khác. |
| Bước nấu vẫn là tiếng Anh | Một số công thức chưa có bản dịch đủ điều kiện. Hộp thoại cho biết nguồn và trạng thái của nội dung đang hiển thị. |

```powershell
powershell -ExecutionPolicy Bypass -File .\setup_env.ps1 -Port 8066
.\Start_Smart_Kitchen.cmd 8066
```

Với cổng 8066, mở [http://127.0.0.1:8066/](http://127.0.0.1:8066/).

Để kiểm tra độc lập ZIP trước khi giải nén, chạy `Get-FileHash -Algorithm SHA256 -LiteralPath .\Smart_Kitchen_V6_Windows.zip` và đối chiếu tệp `Smart_Kitchen_V6_Windows.zip.sha256`.
