# HƯỚNG DẪN CHẠY SMART KITCHEN

1. **Tải và giải nén `Smart_Kitchen_V6_Windows.zip`.** Với GitHub Releases, chọn tệp này trong **Assets**. Mở PowerShell tại thư mục đã giải nén, nơi có `setup_env.ps1`.
2. **Cài CPython 3.14 64-bit (x64) nếu máy chưa có.** Bản kiểm thử dùng [Python 3.14.3 — Windows installer (64-bit)](https://www.python.org/downloads/release/python-3143/). Có thể chọn **Add python.exe to PATH** trong trình cài đặt.
3. **Cài môi trường.** Bước này cần kết nối PyPI để tải thư viện Python. Script kiểm tra SHA-256 trước khi cài.

   ```powershell
   powershell -ExecutionPolicy Bypass -File .\setup_env.ps1
   ```

4. **Khởi động ứng dụng.** Giữ cửa sổ mở cho đến khi thấy `Application startup complete`.

   ```powershell
   .\Start_Smart_Kitchen.cmd
   ```

5. **Mở [http://127.0.0.1:8000/](http://127.0.0.1:8000/)**. Nhập `thịt heo xay` hoặc `trứng, cà chua, hành lá` để thử. Nhấn Ctrl+C trong cửa sổ server để dừng.

Có thể chạy `.\RUN_ME_FIRST.cmd` để cài rồi khởi động trong cùng cửa sổ. Nếu cổng 8000 bận, xem [Xử lý lỗi](docs/TROUBLESHOOTING.md).

## Smart Kitchen + AI Recipe Recommendation

Ứng dụng gợi ý món từ nguyên liệu đang có. Stage 5 rule-based (`final`) là mặc định. Hai lựa chọn thực nghiệm `ml_tfidf` và `ml_lsa` dùng artifact đã fit kèm trong ZIP. Profile trình diễn dùng nhập pantry thủ công. Dữ liệu, danh mục, model và bản dịch được đọc cục bộ sau khi cài. Luồng chạy không cần huấn luyện lại, tải model hoặc truy cập thư mục phát triển.

- [Bắt đầu trình diễn](START_HERE.md)
- [Kiến trúc](docs/ARCHITECTURE.md) và [Phương pháp ML](docs/ML_METHODS.md)
- [Kết quả kiểm thử](docs/EVALUATION_RESULTS.md) và [Giới hạn học thuật](docs/ACADEMIC_LIMITATIONS.md)
- [Kiểm kê quyền phân phối](docs/DISTRIBUTION.md) và [Danh sách SHA-256](release/SHA256_MANIFEST.json)

Bản ZIP hiện là bản kiểm định cục bộ. Owner xem điều kiện chia sẻ trong [hướng dẫn phát hành](docs/DISTRIBUTION.md) trước khi tải gói lên GitHub.
