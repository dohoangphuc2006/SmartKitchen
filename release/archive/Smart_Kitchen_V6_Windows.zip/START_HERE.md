# Trình diễn Smart Kitchen

1. Cài đặt và mở trang chủ theo [README](README.md).
2. Nhập **thịt heo xay**, xác nhận nguyên liệu và bấm **Gợi ý món ăn**. Xem các nguyên liệu cần bổ sung.
3. Xóa nguyên liệu vừa nhập, thêm **trứng, cà chua, hành lá** rồi gợi ý lại. Quan sát hai danh sách **Có thể nấu ngay** và **Cần bổ sung**.
4. Trong **Cách gợi ý món ăn**, thử **Theo nguyên liệu tương đồng** và **Khám phá món liên quan**. Lần gọi ML đầu tiên có thể mất thêm vài giây để kiểm tra và nạp artifact.
5. Mở một công thức và chuyển **Tiếng Việt / English** ngay trong hộp thoại. Phần bước nấu tiếng Việt có thể hiển thị bản dịch tự động hoặc dùng tiếng Anh gốc tùy công thức.

Xem thêm [Hướng dẫn sử dụng](docs/USER_GUIDE.md) và [Xử lý lỗi](docs/TROUBLESHOOTING.md).
