"""Response schema cho API."""
