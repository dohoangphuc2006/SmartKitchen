"""Backend demo Smart Kitchen."""
